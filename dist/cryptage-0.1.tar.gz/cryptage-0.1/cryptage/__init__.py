from encryptor import *

main()