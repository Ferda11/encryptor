
from setuptools import setup, find_packages

setup(
    name='cryptage',
     author='C.M Tech',
    author_email='ferdacarinef@gmail.com',
    description='package pour encryter et decrytper des mots',
    url='https://github.com/Ferda11/encryptor',
    version='0.1',
    python_requires='>=3.10',
    packages=["cryptage"]    
)
